const Loader = require('../loader');
const System = require('./system');

window.demoNum = 6;
let loader = new Loader(System);
