const Loader = require('../loader');
const System = require('./system');

window.demoNum = 4;
let loader = new Loader(System);
